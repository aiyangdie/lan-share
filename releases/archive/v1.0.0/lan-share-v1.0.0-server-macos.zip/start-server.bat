@echo off
chcp 65001 >nul
title LanShare Server
cd /d "%~dp0"
if not exist "node_modules\busboy" call npm install --omit=dev >nul 2>&1
echo.
echo  LanShare Server v1.0.0
echo  Open http://YOUR_PC_IP:8787 on your phone
echo.
node server.mjs
pause
