#!/bin/sh
cd "$(dirname "$0")"
[ -d node_modules/busboy ] || npm install --omit=dev >/dev/null 2>&1
echo ""
echo "  LanShare Server v1.0.0"
echo "  Open http://YOUR_PC_IP:8787 on your phone"
echo ""
exec node server.mjs
