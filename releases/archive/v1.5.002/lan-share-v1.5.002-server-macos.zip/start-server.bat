@echo off
chcp 65001 >nul
title LanShare v1.5.002
cd /d "%~dp0"
if not exist "node_modules\busboy" call npm install --omit=dev >nul 2>&1
if not exist "shared" mkdir shared
if not exist "uploads" mkdir uploads
echo.
echo  LanShare Server v1.5.002
echo  Phone: http://YOUR_PC_IP:8787
echo.
node server.mjs
pause
