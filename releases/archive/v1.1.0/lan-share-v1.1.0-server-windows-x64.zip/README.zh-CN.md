<p align="center">
  <img src="public/icons/icon.svg" width="80" alt="LanShare">
</p>

<h1 align="center">LanShare · 电脑互传</h1>

<p align="center">
  <strong>手机和电脑在同一 WiFi 下互传文件</strong><br>
  无需云盘 · 无需账号 · 开源免费
</p>

<p align="center">
  <a href="#下载">下载</a> ·
  <a href="#快速开始">快速开始</a> ·
  <a href="README.md">English</a>
</p>

---

## 下载安装包

| 平台 | 安装包 | 说明 |
|------|--------|------|
| 🤖 **Android** | `releases/lan-share-v1.0.0-android.apk` | 传到手机安装 |
| 🪟 **Windows 电脑** | `releases/lan-share-v1.0.0-server-windows-x64.zip` | 解压运行 `start-server.bat` |
| 🍎 **macOS 电脑** | `releases/lan-share-v1.0.0-server-macos.zip` | 解压运行 `./start-server.sh` |
| 🐧 **Linux 电脑** | `releases/lan-share-v1.0.0-server-linux-x64.tar.gz` | 解压运行 `./start-server.sh` |
| 📱 **iPhone / iPad** | 见 `releases/lan-share-v1.0.0-ios-pwa.txt` | Safari 添加到主屏幕 |

## 快速开始

### 1. 电脑端

双击 **`start-server.bat`**（Windows）或运行 **`./start-server.sh`**（Mac/Linux）

### 2. 手机端

- **Android**：安装 APK，填入 `http://你的电脑IP:8787`
- **iPhone**：Safari 打开上述地址 → 分享 → 添加到主屏幕

### 3. 传文件

| 功能 | 说明 |
|------|------|
| 上传 | 手机文件 → 电脑 `uploads/` |
| 浏览 | 查看已上传文件 |
| 共享 | 下载电脑 `shared/` 里的文件 |

## 自行打包

```bash
npm install
npm run build:release    # 打包全部安装包
npm run build:apk        # 仅 Android APK
```

## 开源协议

[MIT](LICENSE) — 可自由使用、修改、商用。
