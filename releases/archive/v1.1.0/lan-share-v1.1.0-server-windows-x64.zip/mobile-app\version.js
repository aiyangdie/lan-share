window.__LANSHARE_VERSION__ = '1.1.0'
