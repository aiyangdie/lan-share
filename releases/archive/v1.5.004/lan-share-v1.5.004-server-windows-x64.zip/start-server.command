#!/bin/bash
cd "$(dirname "$0")"
chmod +x start-server.sh 2>/dev/null
./start-server.sh
